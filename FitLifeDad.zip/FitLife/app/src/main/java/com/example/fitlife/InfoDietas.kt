package com.example.fitlife

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class InfoDietas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_info_dietas2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Constantes
        val Nombre = findViewById<TextView>(R.id.NombreUserDieta)
        val dataScrollView = findViewById<LinearLayout>(R.id.dietasContainer)
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val Crear = findViewById<Button>(R.id.btnCrearDieta)
        val Volver = findViewById<Button>(R.id.VolverInicio2)
        val SQLUser = bd.rawQuery("SELECT usuario FROM Registro WHERE id=?", arrayOf(Identificador.toString()))
        if (SQLUser.moveToFirst()) {
            val usuarioNombre = SQLUser.getString(0)
            Nombre.text = usuarioNombre
        }

        // Cargar las dietas al entrar
        cargarDietas(Identificador, dataScrollView)

        // Cerrar la conexión a la base de datos
        SQLUser.close()
        Crear.setOnClickListener {
            val cambio = Intent(this,Add_Dietas::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }
        Volver.setOnClickListener {
            val cambio = Intent(this,Pagina_inicio::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }
    }


    private fun cargarDietas(Identificador: Int?, parentLayout: LinearLayout) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase

        // Limpiar las dietas previas
        parentLayout.removeAllViews()

        // Consultar todas las dietas
        val SQLDietas = "SELECT id, nombre, tipo, creador_id FROM Dietas"
        val cursorDietas = bd.rawQuery(SQLDietas, null)

        // Agregar las dietas
        mostrarDietas(cursorDietas, parentLayout)

        // Cerrar la conexión
        cursorDietas.close()
    }

    private fun mostrarDietas(cursor: android.database.Cursor, parentLayout: LinearLayout) {
        // Agregar las dietas
        while (cursor.moveToNext()) {
            val dietaId = cursor.getInt(0)
            val dietaNombre = cursor.getString(1)
            val dietaTipo = cursor.getString(2)
            val creadorId = cursor.getInt(3)

            // Obtener nombre del creador
            val creador = obtenerNombreCreador(creadorId)

            // Crear el CardView para cada dieta
            val cardView = com.google.android.material.card.MaterialCardView(this)
            cardView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            cardView.setCardElevation(8f)
            cardView.setRadius(16f)
            cardView.setContentPadding(16, 16, 16, 16)

            val colorCard = Color.parseColor("#1F1F1F")
            cardView.setCardBackgroundColor(colorCard)

            val dietaTextView = TextView(this)
            dietaTextView.text = "$dietaNombre publicada por $creador"

            dietaTextView.setTextColor(getResources().getColor(android.R.color.white))
            dietaTextView.textSize = 18f
            dietaTextView.setPadding(16, 16, 16, 16)
            cardView.addView(dietaTextView)
            cardView.setOnClickListener {

                val intent = Intent(this, Detallesdieta::class.java)
                intent.putExtra("dietaId", dietaId)
                startActivity(intent)
            }

            // Agregar el CardView al layout principal
            parentLayout.addView(cardView)
        }
    }

    private fun obtenerNombreCreador(creadorId: Int): String {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val SQLCreador = bd.rawQuery("SELECT usuario FROM Registro WHERE id=?", arrayOf(creadorId.toString()))
        if (SQLCreador.moveToFirst()) {
            return SQLCreador.getString(0)
        }
        return "Desconocido"
    }
}
