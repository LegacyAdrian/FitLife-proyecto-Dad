package com.example.fitlife

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Add_Dietas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_add_dietas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Constantes
        val nombreDieta= findViewById<EditText>(R.id.nombreDieta)
        val contenidoDieta = findViewById<EditText>(R.id.contenidoDieta)
        val PrecioMedio= findViewById<EditText>(R.id.PrecioDieta)
        val btnCrearEntrenamiento= findViewById<Button>(R.id.btnGuardarDieta)
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        val Volver= findViewById<Button>(R.id.btnVolveraDietas)
        val Selector = findViewById<Spinner>(R.id.SelectorDieta)
        val opciones = arrayOf("Omnivora","Carnivora","Vegetariana")
        val adaptador = ArrayAdapter(this,android.R.layout.simple_spinner_item,opciones)
        adaptador.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        Selector.adapter =adaptador
        //Funciones
        btnCrearEntrenamiento.setOnClickListener {
            if (nombreDieta.text.toString().trim().isEmpty() ||
                contenidoDieta.text.toString().trim().isEmpty() ||
                PrecioMedio.text.toString().trim().isEmpty()){
                Toast.makeText(this, "Por favor rellena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener }


            val admin = SQLiteUsuarios(this,"usuarios.db",null,1)
            val bd = admin.writableDatabase
            val TipoDietaSelecionada = Selector.selectedItem.toString().trim()

                val campos = ContentValues()
                campos.put("nombre",nombreDieta.text.toString().trim())
                campos.put("contenido",contenidoDieta.text.toString().trim())
                campos.put("precio",PrecioMedio.text.toString().toDouble())
                campos.put("creador_id",Identificador)
                campos.put("tipo", TipoDietaSelecionada)
                val Insertar = bd.insert("Dietas",null,campos)
                bd.close()
                Toast.makeText(this, "Dieta Creada con Exito", Toast.LENGTH_SHORT).show()

            Volver.setOnClickListener {
                val cambio = Intent(this,InfoDietas::class.java)
                cambio.putExtra("Identificador",Identificador)
                startActivity(cambio)
            }

        }
    }
}