package com.example.fitlife

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.example.fitlife.DataBase.SQLiteUsuarios

class Admin_Usuarios : AppCompatActivity() {

    // Inicializar contenedor
    private lateinit var contenedorRegistros: LinearLayout
    private var identificadorUsuario: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_usuarios)

        // Bundle
        val bundle = intent.extras
        identificadorUsuario = bundle?.getInt("Identificador")

        // Inicializar contenedor
        contenedorRegistros = findViewById(R.id.contenedorUsuarios)

        // Cargar los datos
        cargarDatos()

        // Botón
        val volverBtn: Button = findViewById(R.id.btnVolverAPerfil4)
        volverBtn.setOnClickListener {
            val cambio = Intent(this,Perfil_Usuario::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
    }

    // Cargar los registros
    @SuppressLint("Range")
    private fun cargarDatos() {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.readableDatabase

        // Consulta
        val cursorUsuario = db.rawQuery("SELECT adminmode FROM Registro WHERE id = ?", arrayOf(identificadorUsuario.toString()))
        cursorUsuario.moveToFirst()
        val adminMode = cursorUsuario.getInt(cursorUsuario.getColumnIndex("adminmode"))
        cursorUsuario.close()

        // Consulta
        var sqlQuery = ""
        when (adminMode) {
            1 -> {
                // Admins
                sqlQuery = "SELECT Registro.id, Registro.usuario, Registro.correo " +
                        "FROM Registro WHERE Registro.adminmode = 0 AND Registro.id != ?"
            }
            2 -> {
                // Propietarios
                sqlQuery = "SELECT Registro.id, Registro.usuario, Registro.correo FROM Registro WHERE adminmode != 2 AND id != ?"
            }
            else -> {
                return
            }
        }

        // Ejecutar la consulta
        val cursorRegistro = db.rawQuery(sqlQuery, arrayOf(identificadorUsuario.toString()))
        while (cursorRegistro.moveToNext()) {
            val idRegistro = cursorRegistro.getInt(cursorRegistro.getColumnIndex("id"))
            val nombreUsuario = cursorRegistro.getString(cursorRegistro.getColumnIndex("usuario"))
            val correoUsuario = cursorRegistro.getString(cursorRegistro.getColumnIndex("correo"))
            val registroView = crearVistaDeRegistro(idRegistro, nombreUsuario, correoUsuario)
            contenedorRegistros.addView(registroView)
        }
        cursorRegistro.close()
    }

    // Crear vista
    private fun crearVistaDeRegistro(id: Int, nombre: String, correo: String): LinearLayout {
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.HORIZONTAL

        val textView = TextView(this)
        textView.text = "$nombre ($correo)"

        val btnEliminar = Button(this)
        btnEliminar.text = "Eliminar"
        btnEliminar.setBackgroundColor(resources.getColor(android.R.color.holo_red_dark)) // Rojo
        btnEliminar.setTextColor(resources.getColor(android.R.color.white)) // Blanco
        btnEliminar.setOnClickListener {
            mostrarAlerta("¿Seguro que deseas eliminar este registro?", "Registro", id)
        }

        layout.addView(textView)
        layout.addView(btnEliminar)
        return layout
    }

    // Mostrar alerta
    private fun mostrarAlerta(mensaje: String, tipo: String, id: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setMessage(mensaje)
            .setPositiveButton("Sí") { dialog, which ->
                when (tipo) {
                    "Registro" -> eliminarRegistro(id)
                }
            }
            .setNegativeButton("No") { dialog, which -> dialog.dismiss() }
        builder.create().show()
    }

    private fun eliminarRegistro(id: Int) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val db = admin.writableDatabase

        // Eliminar la información
        db.execSQL("DELETE FROM Informacion WHERE usuario_id = ?", arrayOf(id.toString()))

        // Eliminar las dietas
        db.execSQL("DELETE FROM Dietas WHERE creador_id = ?", arrayOf(id.toString()))

        // Eliminar el progreso
        db.execSQL("DELETE FROM Progreso WHERE usuario_id = ?", arrayOf(id.toString()))

        // liminar usuario
        db.execSQL("DELETE FROM Registro WHERE id = ?", arrayOf(id.toString()))

        actualizarVista()
    }

    // Actualizar la vista después de eliminar un registro
    private fun actualizarVista() {
        // Limpiar el contenedor
        contenedorRegistros.removeAllViews()

        // Recargar los datos
        cargarDatos()
    }
}
