package com.example.fitlife

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.fitlife.DataBase.SQLiteUsuarios

class Planes : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_planes)

        // Constantes
        val Nombre = findViewById<TextView>(R.id.NombreUserEntrenamiento)
        val dataScrollView = findViewById<LinearLayout>(R.id.plansContainer)
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        val Volver = findViewById<Button>(R.id.VolverInicio2)
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val Crear = findViewById<Button>(R.id.btnCrearEntrenamiento)
        // Obtener nombre del usuario
        val SQLUser = bd.rawQuery("SELECT usuario FROM Registro WHERE id=?", arrayOf(Identificador.toString()))
        if (SQLUser.moveToFirst()) {
            val usuarioNombre = SQLUser.getString(0)
            Nombre.text = usuarioNombre
        }

        // Cargar
        cargarPlanes(Identificador, dataScrollView)
        SQLUser.close()

        Volver.setOnClickListener {
            val cambio = Intent(this, Pagina_inicio::class.java)
            cambio.putExtra("Identificador", Identificador)
            startActivity(cambio)
        }
        Crear.setOnClickListener {
            val cambio = Intent(this, Add_Entrenamiento::class.java)
            cambio.putExtra("Identificador", Identificador)
            startActivity(cambio)
        }
    }


    private fun cargarPlanes(Identificador: Int?, parentLayout: LinearLayout) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase

        // Limpiar
        parentLayout.removeAllViews()

        // Consultar todos los planes
        val SQLPlanes = "SELECT id, nombre, creador_id FROM PlanesEntrenamiento"
        val cursorPlanes = bd.rawQuery(SQLPlanes, null)
        mostrarPlanes(cursorPlanes, parentLayout)
        cursorPlanes.close()
    }
    private fun mostrarPlanes(cursor: android.database.Cursor, parentLayout: LinearLayout) {
        // Agregar los planes
        while (cursor.moveToNext()) {
            val planId = cursor.getInt(0)
            val planNombre = cursor.getString(1)
            val creadorId = cursor.getInt(2)

            val creador = obtenerNombreCreador(creadorId)

            // Crear el CardView
            val cardView = com.google.android.material.card.MaterialCardView(this)
            cardView.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            cardView.setCardElevation(8f)
            cardView.setRadius(16f)
            cardView.setContentPadding(16, 16, 16, 16)
            val colorcard = Color.parseColor("#1F1F1F")
            cardView.setCardBackgroundColor(colorcard)
            val planTextView = TextView(this)
            planTextView.text = "$planNombre publicado por $creador"
            planTextView.setTextColor(getResources().getColor(android.R.color.white))
            planTextView.textSize = 18f
            planTextView.setPadding(16, 16, 16, 16)
            cardView.addView(planTextView)

            // Entrar en detalles
            cardView.setOnClickListener {
                // Al hacer clic, abrir la actividad Detallesplan pasando el ID del plan
                val intent = Intent(this, Detallesplan::class.java)
                intent.putExtra("planId", planId)
                startActivity(intent)
            }
            parentLayout.addView(cardView)
        }
    }



    private fun obtenerNombreCreador(creadorId: Int): String {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val SQLCreador = bd.rawQuery("SELECT usuario FROM Registro WHERE id=?", arrayOf(creadorId.toString()))
        if (SQLCreador.moveToFirst()) {
            return SQLCreador.getString(0)
        }
        return "Desconocido"
    }

}
