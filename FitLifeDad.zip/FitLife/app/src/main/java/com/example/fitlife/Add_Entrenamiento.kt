package com.example.fitlife

import android.content.ContentValues
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitlife.DataBase.SQLiteUsuarios
import java.util.Locale

class Add_Entrenamiento : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_entrenamiento)

        // Constantes
        val nombreEntrenamiento = findViewById<EditText>(R.id.nombreEntrenamiento)
        val contenidoEntrenamiento = findViewById<EditText>(R.id.contenidoEntrenamiento)
        val imcEntrenamiento = findViewById<EditText>(R.id.imcEntrenamiento)
        val btnGuardarEntrenamiento = findViewById<Button>(R.id.btnGuardarEntrenamiento)
        val btnVolver = findViewById<Button>(R.id.btnVolveraEntrenamiento)
        val btnUsarVoz = findViewById<Button>(R.id.btnUsarReconocimientoVoz)
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")

        var campoActual: EditText? = null

        // Metodo
        nombreEntrenamiento.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) campoActual = nombreEntrenamiento
        }
        contenidoEntrenamiento.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) campoActual = contenidoEntrenamiento
        }
        imcEntrenamiento.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) campoActual = imcEntrenamiento
        }

        // Botón para reconocimiento de voz
        btnUsarVoz.setOnClickListener {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            intent.putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Habla ahora...")
            try {
                startActivityForResult(intent, 100)
            } catch (e: Exception) {
                Toast.makeText(this, "El reconocimiento de voz no está disponible.", Toast.LENGTH_SHORT).show()
            }
        }

        // Botón para guardar entrenamiento
        btnGuardarEntrenamiento.setOnClickListener {
            if (nombreEntrenamiento.text.toString().trim().isEmpty() ||
                contenidoEntrenamiento.text.toString().trim().isEmpty() ||
                imcEntrenamiento.text.toString().trim().isEmpty()
            ) {
                Toast.makeText(this, "Por favor, rellena todos los campos.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
            val bd = admin.writableDatabase
            val campos = ContentValues().apply {
                put("nombre", nombreEntrenamiento.text.toString().trim())
                put("contenido", contenidoEntrenamiento.text.toString().trim())
                put("imc", imcEntrenamiento.text.toString().toDouble())
                put("creador_id", Identificador)
            }
            bd.insert("PlanesEntrenamiento", null, campos)
            bd.close()
            Toast.makeText(this, "Plan de Entrenamiento creado con éxito", Toast.LENGTH_SHORT).show()
        }

        // Botón para volver
        btnVolver.setOnClickListener {
            val cambio = Intent(this, Planes::class.java)
            cambio.putExtra("Identificador", Identificador)
            startActivity(cambio)
        }
    }

    // Manejar el resultado del reconocimiento de voz
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val recognizedText = results?.get(0) ?: ""
            val campoActual = when {
                findViewById<EditText>(R.id.nombreEntrenamiento).hasFocus() -> findViewById<EditText>(R.id.nombreEntrenamiento)
                findViewById<EditText>(R.id.contenidoEntrenamiento).hasFocus() -> findViewById<EditText>(R.id.contenidoEntrenamiento)
                findViewById<EditText>(R.id.imcEntrenamiento).hasFocus() -> findViewById<EditText>(R.id.imcEntrenamiento)
                else -> null
            }
            campoActual?.setText(recognizedText)
        }
    }
}
