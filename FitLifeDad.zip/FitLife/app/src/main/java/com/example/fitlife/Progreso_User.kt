package com.example.fitlife

import android.annotation.SuppressLint
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import android.widget.Button
import android.widget.CalendarView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios
import java.text.SimpleDateFormat
import java.util.Locale

class Progreso_User : AppCompatActivity() {

    private var fechaSeleccionada: String = ""
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_progreso_user)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Constantes
        val identificador = intent.getIntExtra("Identificador", -1)
        val calendarView = findViewById<CalendarView>(R.id.calendarView)
        val volver = findViewById<Button>(R.id.btnVolverAtrasProgreso)
        val buscarInfo = findViewById<Button>(R.id.btnBuscarInfo)

        // Manejar calendario
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            fechaSeleccionada = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
        }

        // Funcion Buscar Información
        buscarInfo.setOnClickListener {
            if (fechaSeleccionada.isEmpty()) {
                Toast.makeText(this, "Por favor selecciona una fecha en el calendario", Toast.LENGTH_SHORT).show()
            } else {
                // Consulta en la base de datos
                val dbHelper = SQLiteUsuarios(this, "usuarios.db", null, 1)
                val db = dbHelper.readableDatabase

                val cursor: Cursor = db.rawQuery(
                    "SELECT * FROM Progreso WHERE fecha = ? AND usuario_id = ?",
                    arrayOf(fechaSeleccionada, identificador.toString())
                )

                if (cursor.moveToFirst()) {
                    val intent = Intent(this, Detalle_Progreso::class.java)
                    intent.putExtra("fecha", fechaSeleccionada)
                    intent.putExtra("Identificador", identificador)
                    startActivity(intent)
                } else {

                    Toast.makeText(this, "Actualmente no hay información para ese día", Toast.LENGTH_SHORT).show()
                }

                cursor.close()
            }
        }

        // volver
        volver.setOnClickListener {
            val cambio = Intent(this, Pagina_inicio::class.java)
            cambio.putExtra("Identificador", identificador)
            startActivity(cambio)
        }
    }
}
