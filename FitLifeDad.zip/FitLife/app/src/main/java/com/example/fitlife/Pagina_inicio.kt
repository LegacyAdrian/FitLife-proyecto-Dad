package com.example.fitlife

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios
import java.util.Locale

class Pagina_inicio : AppCompatActivity() {

    private val VOICE_REQUEST_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pagina_inicio)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Constantes
        val Icono = findViewById<ImageView>(R.id.UserIconProgreso)
        val Nombre = findViewById<TextView>(R.id.NombreUser)
        val Entrenamientos = findViewById<Button>(R.id.btnEntrenamientos);
        val Dietas = findViewById<Button>(R.id.btnDietas);
        val Progreso = findViewById<Button>(R.id.btnProgreso);
        val AñadirProgreso = findViewById<Button>(R.id.btnAddProgreso);
        val ReconocimientoVoz = findViewById<Button>(R.id.btnReconocimientovoz)

        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")
        val admin = SQLiteUsuarios(this,"usuarios.db",null,1)
        val bd = admin.writableDatabase
        val SQL = bd.rawQuery("SELECT usuario FROM Registro WHERE id=?", arrayOf(Identificador.toString()))
        if (SQL.moveToFirst()){Nombre.text= SQL.getString(0)}
        //Funcionalidad Aqui
        Icono.setOnClickListener{
            val cambio = Intent(this,Perfil_Usuario::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)

        }

        Entrenamientos.setOnClickListener {
            val cambio = Intent(this,Planes::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        Dietas.setOnClickListener {
            val cambio = Intent(this,InfoDietas::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        Progreso.setOnClickListener {
            val cambio = Intent(this,Progreso_User::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        AñadirProgreso.setOnClickListener {
            val cambio = Intent(this,Add_Progreso::class.java)
            cambio.putExtra("Identificador",Identificador)
            startActivity(cambio)
        }

        //Reconocimiento de voz
        ReconocimientoVoz.setOnClickListener {
            iniciarReconocimientoDeVoz()
        }

    }
    //Iniciarlo
    private fun iniciarReconocimientoDeVoz() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "¿Qué actividad quieres abrir?")
        }
        try {
            startActivityForResult(intent, VOICE_REQUEST_CODE)
        } catch (e: Exception) {
            Toast.makeText(this, "El reconocimiento de voz no está disponible en tu dispositivo", Toast.LENGTH_SHORT).show()
        }
    }
    //Funcionalidad
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VOICE_REQUEST_CODE && resultCode == RESULT_OK) {
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = results?.get(0)?.lowercase(Locale.getDefault())

            when {
                command?.contains("entrenamientos") == true -> abrirActividad(Planes::class.java)
                command?.contains("dietas") == true -> abrirActividad(InfoDietas::class.java)
                command?.contains("progreso") == true -> abrirActividad(Progreso_User::class.java)
                command?.contains("añadir") == true -> abrirActividad(Add_Progreso::class.java)
                command?.contains("perfil") == true -> abrirActividad(Perfil_Usuario::class.java)
                else -> Toast.makeText(this, "Comando no reconocido", Toast.LENGTH_SHORT).show()
            }
        }
    }
    // Función para abrir actividades
    private fun abrirActividad(clase: Class<*>) {
        val bundle = intent.extras
        val Identificador = bundle?.getInt("Identificador")

        val cambio = Intent(this, clase)
        cambio.putExtra("Identificador", Identificador)
        startActivity(cambio)
    }

}