package com.example.fitlife

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Perfil_Usuario : AppCompatActivity() {

    // Constantes
    val nombreUsuario: TextView by lazy { findViewById<TextView>(R.id.NombreUser) }
    val btnActivarModoAdmin: Button by lazy { findViewById<Button>(R.id.btnActivarModoAdmin) }
    val GestionDietas: Button by lazy { findViewById<Button>(R.id.btnGestionDietas) }
    val GestionEntrenamiento: Button by lazy { findViewById<Button>(R.id.btnGestionEntrenamientos) }
    val GestionUsuarios: Button by lazy { findViewById<Button>(R.id.btnGestionUsuarios) }
    val contenedorGestion: LinearLayout by lazy { findViewById<LinearLayout>(R.id.btnGestionContainer) }
    val campoContraseña: EditText by lazy { findViewById<EditText>(R.id.editTextContraseña) }
    //Variables
    var identificadorUsuario: Int? = null
    var estadoAdmin: Int = 0
    var nombre: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_perfil_usuario)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        //Botones
        val CerrarSesion = findViewById<Button>(R.id.btnCerrarSesion)
        val BorrarCuenta = findViewById<Button>(R.id.btnBorrarCuenta)
        val Inicio = findViewById<Button>(R.id.btnVolverInicio)
        val Editar = findViewById<Button>(R.id.btnEditarPerfil)
        val AñadirDatos = findViewById<Button>(R.id.btnAñadirDatosExtras)
        val VerSubidas = findViewById<Button>(R.id.btnVerSubidas)


        //Bundle
        val bundle = intent.extras
        identificadorUsuario = bundle?.getInt("Identificador")

        //Esto para el Nombre
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        val sql = bd.rawQuery("SELECT usuario, adminmode FROM Registro WHERE id=?", arrayOf(identificadorUsuario.toString()))

        if (sql.moveToFirst()) {
            nombre = sql.getString(0)
            estadoAdmin = sql.getInt(1)
            nombreUsuario.text = nombre
            gestionarBotones()
        }
        //Funcion de Botones

        //Cerrar Sesion
        CerrarSesion.setOnClickListener {
            val cambio = Intent(this,MainActivity::class.java)
            startActivity(cambio)
        }
        //Ir a Inicio
        Inicio.setOnClickListener {
            val cambio = Intent(this,Pagina_inicio::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
        //Editar Perfil
        Editar.setOnClickListener {
            val cambio = Intent(this,Editar_Perfil::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
        //Añadir Datos Extra
        AñadirDatos.setOnClickListener {
            val cambio = Intent(this,Add_ExtraInfo::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
        //Borrar Cuenta
        BorrarCuenta.setOnClickListener {
            val Alerta = AlertDialog.Builder(this)
            Alerta.setMessage("¿Estás seguro de que quieres eliminar tu cuenta? Esto eliminará todos tus datos asociados.")
                .setPositiveButton("Sí") { dialog, id ->
                    eliminarCuenta()
                }
                .setNegativeButton("No") { dialog, id ->
                    dialog.dismiss()
                }
            Alerta.show()
        }

        VerSubidas.setOnClickListener {
            val cambio = Intent(this,Gestion_Subidas::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
        GestionDietas.setOnClickListener {
            val cambio = Intent(this,Admin_Dietas::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }

        GestionUsuarios.setOnClickListener {
            val cambio = Intent(this,Admin_Usuarios::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }
        GestionEntrenamiento.setOnClickListener {
            val cambio = Intent(this,Admin_Entrenamientos::class.java)
            cambio.putExtra("Identificador",identificadorUsuario)
            startActivity(cambio)
        }



        btnActivarModoAdmin.setOnClickListener {
            val contraseñaIngresada = campoContraseña.text.toString()
            if (contraseñaIngresada == "administrador") {
                cambiarEstadoAdmin(1)
                mostrarToast("Modo Administrador activado")
            } else if(contraseñaIngresada == "propietario"){
                cambiarEstadoAdmin(2)
                mostrarToast("Modo Propietario activado")
            } else {
                mostrarToast("Contraseña incorrecta")
            }
        }


    }

    private fun eliminarCuenta() {
            val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
            val bd = admin.writableDatabase

            // Borrar las Dietas
            bd.execSQL("DELETE FROM Dietas WHERE creador_id = ?", arrayOf(identificadorUsuario.toString()))

            // Borrar los Planes de Entrenamiento
            bd.execSQL("DELETE FROM PlanesEntrenamiento WHERE creador_id = ?", arrayOf(identificadorUsuario.toString()))

            // Borrar el Progreso
            bd.execSQL("DELETE FROM Progreso WHERE usuario_id = ?", arrayOf(identificadorUsuario.toString()))

            // Borrar la Información
            bd.execSQL("DELETE FROM Informacion WHERE usuario_id = ?", arrayOf(identificadorUsuario.toString()))

            // Borrar el usuario
            bd.execSQL("DELETE FROM Registro WHERE id = ?", arrayOf(identificadorUsuario.toString()))

            // Mostrar mensaje de éxito y redirigir a la pantalla principal
            mostrarToast("Cuenta eliminada con éxito")
            val cambio = Intent(this, MainActivity::class.java)
            startActivity(cambio)
            finish()
        }



    // Para cambiar el modo de usuario
    private fun cambiarEstadoAdmin(estado: Int) {
        val admin = SQLiteUsuarios(this, "usuarios.db", null, 1)
        val bd = admin.writableDatabase
        bd.execSQL("UPDATE Registro SET adminmode = ? WHERE id = ?", arrayOf(estado.toString(), identificadorUsuario.toString()))
        estadoAdmin = estado
        gestionarBotones()
    }

    // Función para gestionar la visibilidad de los botones
    private fun gestionarBotones() {
        if (estadoAdmin == 1 || estadoAdmin == 2) {
            contenedorGestion.visibility = LinearLayout.VISIBLE
            btnActivarModoAdmin.visibility = Button.GONE
            campoContraseña.visibility = EditText.GONE
        } else {
            contenedorGestion.visibility = LinearLayout.GONE
            btnActivarModoAdmin.visibility = Button.VISIBLE
            campoContraseña.visibility = EditText.VISIBLE
        }
    }

    // Mensajes
    private fun mostrarToast(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }
}
