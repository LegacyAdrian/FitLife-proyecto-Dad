package com.example.fitlife

import android.annotation.SuppressLint
import android.database.Cursor
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.fitlife.DataBase.SQLiteUsuarios

class Detalle_Progreso : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_detalle_progreso)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Constantes
        val fechaSeleccionada = intent.getStringExtra("fecha") ?: ""
        val identificador = intent.getIntExtra("Identificador", -1)

        val descripcionTextView = findViewById<TextView>(R.id.textViewDescripcion)
        val anotacionTextView = findViewById<TextView>(R.id.textViewAnotacion)
        val objetivoTextView = findViewById<TextView>(R.id.textViewObjetivo)
        val Fechapillada = findViewById<TextView>(R.id.textViewFecha)

        // Verificar
        if (fechaSeleccionada.isEmpty() || identificador == -1) {
            Toast.makeText(this, "Fecha o identificador no válidos", Toast.LENGTH_SHORT).show()
            return
        }

        // Consultar la base de datos
        val dbHelper = SQLiteUsuarios(this, null, null, 1)
        val db = dbHelper.readableDatabase

        // Realizar la consulta
        val cursor: Cursor = db.rawQuery(
            "SELECT descripcion, anotacion, Objetivo FROM Progreso WHERE fecha = ? AND usuario_id = ?",
            arrayOf(fechaSeleccionada, identificador.toString())
        )

        if (cursor.moveToFirst()) {
            val descripcion = cursor.getString(cursor.getColumnIndex("descripcion")) ?: "No disponible"
            val anotacion = cursor.getString(cursor.getColumnIndex("anotacion")) ?: "No disponible"
            val objetivo = cursor.getString(cursor.getColumnIndex("Objetivo")) ?: "No disponible"

            // Asignar los valores
            descripcionTextView.text = descripcion
            anotacionTextView.text = anotacion
            objetivoTextView.text = "El objetivo planteado $objetivo se ha cumplido "
            Fechapillada.text = fechaSeleccionada.toString()
        } else {
            // Si no hay datos para la fecha y el usuario, mostrar un mensaje
            Toast.makeText(this, "No hay datos para este día", Toast.LENGTH_SHORT).show()
        }

        cursor.close()
    }
}